// rtc.h
#ifndef __STM32F_RTC
#define __STM32F_RTC

void RTCInit(void);

#endif

