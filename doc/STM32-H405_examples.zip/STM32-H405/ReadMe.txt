Simple project for Olimex board STM32-H103/405 with ST STM32F405RG microcontroller. The program demonstrates functionality of few peripheral devices that the board has: LED, user button, RTC, USB.

Build info:
IDE:		IAR for ARM 6.30.7
Programmer:	J-Link 7.0

Demo description:
On power-up button and LED are initialized and the demo for Real-Time Clock (RTC) is started. The LED should blink with frequency 1 Hz controlled by the RTC oscillator. In order to proceed to the second demo you should press the user button. It demonstrated Human Interface Device (HID) - mouse. In this demo the mouse cursor is moved around the screen in the shape of square. Meanwhile LED should start blinking with higher frequency. To interrupt this demo press the user button again to enter into the endless loop that blinks the LED.

Stanimir Petev, Olimex
yyyy.mm.dd
2013.10.15