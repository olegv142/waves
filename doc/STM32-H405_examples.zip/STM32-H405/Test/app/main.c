/********************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
 /* ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Template/main.c 
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    13/06/2011
  * @brief   Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <yfuns.h>
#include "includes.h"

#include "stm32f4xx_gpio.h"
#include "arm_comm.h"
#include "includes.h"
#include "rtc.h"

#include  "usbd_hid_core.h"
#include  "usbd_usr.h"
#include  "usbd_desc.h"

#define DLY_100US  1000

void Delay_ (unsigned long a) { while (--a!=0); }


Int32U CriticalSecCntr;
/** @addtogroup Template_Project
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern const struct extcon_board extcon_board_def[];
/* Private function prototypes -----------------------------------------------*/
void DelayResolution100us(Int32U Dely);

/* Private functions ---------------------------------------------------------*/

/*-------------SysTickStart---------------------------------------------------*/
void SysTickStart(uint32_t Tick)
{
  RCC_ClocksTypeDef Clocks;
  volatile uint32_t dummy;

  RCC_GetClocksFreq(&Clocks);

  dummy = SysTick->CTRL;  
  SysTick->LOAD = (Clocks.HCLK_Frequency/8)/Tick;
  
  SysTick->CTRL = 1;
}
/*-------------SysTickStop----------------------------------------------------*/
void SysTickStop(void)
{
  SysTick->CTRL = 0;
}

void LED_Button_Init ()
{
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOC, ENABLE);

  // Led PC12 as output
  STM_EVAL_LEDInit (LED1);
  /*Init Buttons*/
  STM_EVAL_PBInit(BUTTON_WAKEUP, BUTTON_MODE_GPIO);
  return;
}

#ifdef USB_OTG_HS_INTERNAL_DMA_ENABLED
  #if defined ( __ICCARM__ ) /*!< IAR Compiler */
    #pragma data_alignment=4   
  #endif
#endif /* USB_OTG_HS_INTERNAL_DMA_ENABLED */
__ALIGN_BEGIN USB_OTG_CORE_HANDLE  USB_OTG_dev __ALIGN_END;

#define MOUSE_DELTA  5
#define Buttons buf[0]
#define X  buf[1]
#define Y  buf[2]
void USB_Mouse(void)
{
  unsigned char buf[4] = {0, 0, 0, 0};
  unsigned int Direction=0, i=0;
  unsigned int Timeout = 0;

  while (STM_EVAL_PBGetState (BUTTON_WAKEUP))
  {
      if (!Timeout)
      {
         STM_EVAL_LEDToggle (LED1);
         Timeout = 30;
      }
      else
         Timeout--;
      switch (Direction)
      {
      case 0:
           X += MOUSE_DELTA;
           i++;
           Direction = (Direction + (i>>5)) & 3;
           i = i & 0x1F;
        break;
      case 1:
          Y += MOUSE_DELTA;
           i++;
           Direction = (Direction + (i>>5)) & 3;
           i = i & 0x1F;
        break;
      case 2:
          X -= MOUSE_DELTA;
           i++;
           Direction = (Direction + (i>>5)) & 3;
           i = i & 0x1F;
        break;
      case 3:
          Y -= MOUSE_DELTA;
           i++;
           Direction = (Direction + (i>>5)) & 3;
           i = i & 0x1F;
        break;
      default:
        break;
      }

      if(Y || X)
      {
        // Send report
        USBD_HID_SendReport (&USB_OTG_dev, buf, 4);
        Y = X = 0;
      }
  }
  while (!STM_EVAL_PBGetState (BUTTON_WAKEUP));
  return;
}

void USB_Demo (void)
{
  USBD_Init(&USB_OTG_dev, USB_OTG_FS_CORE_ID, &USR_desc, &USBD_HID_cb, &USR_cb);
  USB_Mouse ();
  return;
}

void RTC_Demo (void)
{
  RTCInit();

  while(!GPIO_ReadInputDataBit(WAKEUP_BUTTON_GPIO_PORT, WAKEUP_BUTTON_PIN) == Bit_RESET)
    if (RTC->TR & 0x01)
      STM_EVAL_LEDOn (LED1);
    else
      STM_EVAL_LEDOff (LED1);

  // Disable RTC
  RCC_RTCCLKCmd(DISABLE);
  // TURN OFF led
  STM_EVAL_LEDOff (LED1);
  
  while(GPIO_ReadInputDataBit(WAKEUP_BUTTON_GPIO_PORT, WAKEUP_BUTTON_PIN) == Bit_RESET);
  return;
}

/*************************************************************************
 * Function Name: main
 * Parameters: none
 * Return: Int32U
 *
 * Description: The main subroutine
 *
 *************************************************************************/
int main(void)
{
  // Init clock system
  SystemInit();

  LED_Button_Init ();

  RTC_Demo ();
  
  USB_Demo ();

  while (1)
  {
    // simple blink in endless loop
    STM_EVAL_LEDToggle (LED1);
    DelayResolution100us (10000);
  }
}



/*************************************************************************
 * Function Name: DelayResolution100us
 * Parameters: Int32U Dly
 *
 * Return: none
 *
 * Description: Delay ~ (arg * 100us)
 *
 *************************************************************************/
void DelayResolution100us(Int32U Dely)
{
  for(; Dely; Dely--)
  {
    for(volatile Int32U j = DLY_100US; j; j--)
    {
    }
  }
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
